package parkinglotproject.parkinglot;

public enum VehicleSize{
    Motorcycle, CarSize,
}